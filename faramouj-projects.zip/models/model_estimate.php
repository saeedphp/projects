<?php

class model_estimate extends Model{

    public function __construct()
    {
        parent::__construct();
    }

}

?>