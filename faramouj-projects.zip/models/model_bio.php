<?php

class model_bio extends Model{

    public function __construct()
    {
        parent::__construct();
    }

}

?>