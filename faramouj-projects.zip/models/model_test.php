<?php

class model_test extends Model{

    public function __construct()
    {
        parent::__construct();
    }

}

?>