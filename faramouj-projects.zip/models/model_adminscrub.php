<?php

class model_adminscrub extends Model{

    public function __construct()
    {
        parent::__construct();
    }

}

?>