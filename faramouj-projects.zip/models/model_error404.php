<?php

class model_error404 extends Model{

    public function __construct()
    {
        parent::__construct();
    }

}

?>