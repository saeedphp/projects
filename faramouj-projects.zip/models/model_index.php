<?php

class model_index extends Model{

    public function __construct()
    {
        parent::__construct();
    }

}

?>