
    <div id="content" class="site-content">
        <div class="container">
            <div class="error-404 not-found text-center">
                <h2>404 <img class="error-image" src="assets/images/404.png" alt="404"></h2>
                <h1>صفحه‌ای که دنبال آن بودید پیدا نشد!</h1>
                <div class="content-404">
                    <a class="octf-btn octf-btn-third octf-btn-icon" href="<?= URL; ?>">بازگشت به خانه<i class="flaticon-right-arrow-1"></i></a>
                </div>
            </div>
        </div>

    </div>

  