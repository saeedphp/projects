
<!-- jQuery -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/slick.min.js"></script>
<script src="assets/js/jquery.magnific-popup.min.js"></script>
<script src="assets/js/jquery.isotope.min.js"></script>
<script src="assets/js/easypiechart.js"></script>
<script src="assets/js/jquery.countdown.min.js"></script>
<script src="assets/js/particles.min.js"></script>
<script src="assets/js/scripts.js"></script>
<script src="assets/js/header-mobile.js"></script>
<script src="assets/panel/plugins/jscolor/jscolor.js"></script>
<script src="assets/js/dropify/js/dropify.js"></script>





<script src="assets/assets/bundles/libscripts.bundle.js"></script>
<script src="assets/assets/bundles/vendorscripts.bundle.js"></script>
<script src="assets/assets/bundles/jvectormap.bundle.js"></script>
<script src="assets/assets/bundles/mainscripts.bundle.js"></script>
<script src="assets/assets/js/index.js"></script>
<script src="assets/assets/bundles/c3.bundle.js"></script>
<script src="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.js"></script>
<script src="assets/vendor/parsleyjs/js/parsley.min.js"></script>
<script src="assets/assets/bundles/mainscripts.bundle.js"></script>
<script src="assets/vendor/dropify/js/dropify.js"></script>
<script src="assets/assets/js/pages/forms/dropify.js"></script>
<script src="assets/vendor/multi-select/js/jquery.multi-select.js"></script>
<script src="assets/assets/js/pages/forms/advanced-form-elements.js"></script>
<script src="assets/vendor/bootstrap-tagsinput/bootstrap-tagsinput.js"></script>


