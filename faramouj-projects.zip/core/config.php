<?php

$model=new Model;
$option=Model::getOption();

define('URL',$option['url']);

?>