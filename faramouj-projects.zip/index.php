<?php

require ('core/app.php');
require ('core/controller.php');
require ('core/model.php');
require ('core/config.php');

new App;

?>